<?php get_header(); ?>
<div id="casing">
<div id="content">
<div class="post clearfix" id="post-<?php the_ID(); ?>">
<div class="rightcover">
<div class="title">	<h2>Not Found</h2></div>
<div class="entry">	<p>The page you are looking is not here..</p></div>
</div>	
</div>	
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
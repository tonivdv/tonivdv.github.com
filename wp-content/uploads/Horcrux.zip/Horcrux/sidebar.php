<div class="right">

<!-- Feedburner subscrition-->
<div class="feedsub">
<?php $feeduri = get_option('horx_feeduri'); ?>
<img style="float:left; margin:8px 5px 0px 10px;" src="<?php bloginfo('stylesheet_directory'); ?>/images/mail.png"/>
<h3><?php _e('Subscribe to email feed'); ?></h3>
<?php $subsc_text = "Enter your email address.."; ?> 
<form action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=<?php echo ($feeduri); ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
<input type="text" value="<?php echo $subsc_text; ?>" id="subc"name="email" onblur="if (this.value == ''){this.value = '<?php echo $subsc_text; ?>';}" onfocus="if (this.value == '<?php echo $subsc_text; ?>'){this.value = '';}" />
<input type="hidden" value="<?php echo ($feeduri); ?>" name="uri"/>
<input type="hidden" name="loc" value="en_US"/>
<input id="subssubmit" type="submit" value="Submit" />

</form>
</div>
<!-- Feedburner subscrition end -->

<!-- Social bookmark icons-->
<div class='feedlist'>
<ul>
	<li><a href="<?php bloginfo('rss2_url'); ?>" ><img src="<?php bloginfo('stylesheet_directory'); ?>/images/rss.png" title="Subscribe here" alt="RSS"/></a></li>
	<li><a href="http://del.icio.us/post?url=<?php bloginfo('siteurl');?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/delicious.png" title="I'm Delicious" alt="Delicious"/></a> </li>
	<li><a href="http://www.digg.com/submit?phase=2&amp;url=<?php bloginfo('siteurl');?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/digg.png" title="Digg Me" alt="Digg"/></a></li>
	<li><a href="<?php $face = get_option('horx_face'); echo ($face); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/facebook.png" title="My Facebook" alt="Facebook"/></a></li> 
	<li><a href="http://twitter.com/<?php $twit = get_option('horx_twit'); echo ($twit); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/twitter.png" title="Follow me" alt="Twitter"/></a></li> 
	<li><a href="<?php $linkd = get_option('horx_linkd'); echo ($linkd); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/linkedin.png" title="My Linkedin" alt="Linkedin"/></a></li> 
	<li class="lasticon"><a href="<?php $yout = get_option('horx_yout'); echo ($yout); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/youtube.png" title="My Channel" alt="Youtube"/></a></li> 

	
</ul>
</div>
<!-- Social bookmark icons end -->

<!-- Search form -->
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
<!-- Search form end-->

<!-- Tabbed content-->
<?php include (TEMPLATEPATH . '/tabs.php'); ?>
<!-- Tabbed content end-->

<!-- Twitter updates-->
<div class="featbox">
<h3 class="sidetitl">Twitter updates</h3>
<?php
$twit = get_option('horx_twit'); 
include('twitter.php');?>
<?php if(function_exists('twitter_messages')) : ?>
       <?php twitter_messages("$twit") ?>
       <?php endif; ?>
</div> 	
<!-- Twitter updates end-->

<!-- Banner ads-->
<?php include (TEMPLATEPATH . '/sponsors.php'); ?>	
<!-- Banner ads end-->

<!-- Wordpress Widgets begin-->
<div class="sidebar">
<ul>
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar') ) : else : ?>
	<?php endif; ?>
</ul>
</div>
<!-- Wordpress widgets ends-->

</div>
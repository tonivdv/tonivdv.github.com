jQuery(document).ready(function() {

Cufon.replace('.title h2,h3#comments', { fontFamily: 'Myriad Pro',hover:true,textShadow: '#ffffff 1px 1px' });

});
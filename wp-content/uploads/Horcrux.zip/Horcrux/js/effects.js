jQuery(document).ready(function() {
	jQuery('.squarebanner li:nth-child(even)').addClass('rbanner');
	
	jQuery('.feedlist ul li img').tipsy({gravity: 's'});
	
	jQuery('#menu ul.sfmenu').superfish({ 
		delay:       200,								// 0.1 second delay on mouseout 
		animation:   {opacity:'show',height:'show'},	// fade-in and slide-down animation 
		dropShadows: false								// disable drop shadows 
	});	
	jQuery('#newtabs> ul').tabs({ fx: {  opacity: 'toggle' } }); 
});